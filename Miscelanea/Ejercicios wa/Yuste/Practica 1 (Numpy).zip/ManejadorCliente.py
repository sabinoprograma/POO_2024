from ClaseCliente import Cliente
import csv

class ManejadorCliente:
    __listaClientes = list

    def __init__(self):
        self.__listaClientes = []
    def __str__(self):
        cadena = ""
        for cliente in self.__listaClientes:
            cadena = cadena + str(cliente) + "\n" 
        return cadena
    def agregarCliente(self, unCliente):
        self.__listaClientes.append(unCliente)
    def getClientes(self, indice):
        return self.__listaClientes[indice]
    def consultarClienteCDni(self, dni):
        i = 0
        esta = False
        indiceRetorno = None
        while i < len(self.__listaClientes) and esta == False:
            if self.__listaClientes[i].getDni() == dni:
                indiceRetorno = i
                esta = True
            else:
                i=i+1       
        return self.getClientes(indiceRetorno)

    def cargaClientes(self):
        archivo = open("ClientesFarmaCiudad.csv")
        reader = csv.reader(archivo, delimiter=";")
        bandera = True
        for fila in reader:
            if bandera == True: 
                bandera = False
            else:
                nombre = fila[0]
                apellido = fila[1]
                dni = int(fila[2])
                numCuenta = int(fila[3])
                saldoAnterior = int(fila[4])
                unCliente = Cliente(nombre, apellido, dni, numCuenta, saldoAnterior)
                self.agregarCliente(unCliente)
        archivo.close