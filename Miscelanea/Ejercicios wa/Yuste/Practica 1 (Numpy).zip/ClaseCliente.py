class Cliente:
    __nombre: str
    __apellido: str
    __dni: int
    __numeroCuenta: int
    __saldoAnterior: int
    def __init__(self, nombre, apellido, dni, numCuenta, saldoAnterior):
        self.__nombre = nombre
        self.__apellido = apellido
        self.__dni = dni
        self.__numeroCuenta = numCuenta
        self.__saldoAnterior = saldoAnterior
    def __str__(self):
        return f"nombre: {self.__nombre} apellido: {self.__apellido} dni: {self.__dni} cuenta: {self.__numeroCuenta} saldo: {self.__saldoAnterior}"
    def getNombre(self):
        return self.__nombre
    def getApellido(self):
        return self.__apellido
    def getDni(self):
        return self.__dni
    def getNumeroDeCuenta(self):
        return self.__numeroCuenta
    def getSaldoAnterior(self):
        return self.__saldoAnterior
    def getNombre(self):
        return self.__nombre


    
    