class Movimiento:
    __numeroDeCuenta: int
    __fecha: str
    __descripción: str
    __tipoDeMovimiento: str
    __importe: int

    def __init__(self, numeroDeCuenta, fecha, descripcion, tipoDeMovimiento, importe):
        self.__numeroDeCuenta = numeroDeCuenta
        self.__fecha = fecha
        self.__descripción = descripcion
        self.__tipoDeMovimiento = tipoDeMovimiento
        self.__importe = importe
    def __str__(self):
        return f"numero cuenta: {self.__numeroDeCuenta} fecha: {self.__fecha} descripcion: {self.__descripción} tipo movimiento: {self.__tipoDeMovimiento} importe: {self.__importe}"
    
    def __gt__(self, otroMov):
        return self.getNumeroDeCuenta() > otroMov.getNumeroDeCuenta()
    
    def getNumeroDeCuenta(self):
        return self.__numeroDeCuenta

    def getFecha(self):
        return self.__fecha

    def getDescripcion(self):
        return self.__descripción

    def getTipoDeMovimiento(self):
        return self.__tipoDeMovimiento

    def getImporte(self):
        return self.__importe
