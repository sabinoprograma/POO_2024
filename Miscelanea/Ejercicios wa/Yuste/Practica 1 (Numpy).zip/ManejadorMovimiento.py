from ClaseCliente import Cliente
from ClaseMovimiento import Movimiento
import csv
import numpy as np
class ManejadorMovimiento:
    __cantidad: int 
    __dimension: int 
    __incremento = 5
    __listaMovimientos: np.ndarray
    def __init__(self, dimension, incremento=5):
        self.__listaMovimientos = np.empty(dimension, dtype=Movimiento)
        self.__cantidad = 0
        self.__incremento = incremento
        self.__dimension = dimension

    def __str__(self):
        cadena = ""
        for i in range(self.__cantidad):
            cadena = cadena + str(self.__listaMovimientos[i]) + "\n" 
        return cadena  
     
    def mostrarMovimientos(self, ncuenta):
        for i in range(self.__cantidad):
            if self.__listaMovimientos[i].getNumeroDeCuenta() == ncuenta:
                print(self.__listaMovimientos[i])



    def listarMovimientosCliente(self, xclienteBuscado):
        print(f"Nombre y Apellido: {xclienteBuscado.getNombre()}, {xclienteBuscado.getApellido()}        Numero de cuenta: {xclienteBuscado.getNumeroDeCuenta()}")
        print(f"Saldo Anterior {xclienteBuscado.getSaldoAnterior()}")
        print("Movimientos")
        print(f"{'Fecha':<10}{'Descripción':<18}{'Importe':<10}{'Tipo de movimiento':<18}")
        totalCreditos = 0
        totalPagos = 0
        for i in range(self.__cantidad):
            if self.__listaMovimientos[i].getNumeroDeCuenta() == xclienteBuscado.getNumeroDeCuenta():
                print(f"{self.__listaMovimientos[i].getFecha():<10}{self.__listaMovimientos[i].getDescripcion():<18}{self.__listaMovimientos[i].getImporte():<10}{self.__listaMovimientos[i].getTipoDeMovimiento():^18}")
                if self.__listaMovimientos[i].getTipoDeMovimiento() == "C":
                    totalCreditos = totalCreditos + self.__listaMovimientos[i].getImporte() 
                if self.__listaMovimientos[i].getTipoDeMovimiento() == "P":
                    totalPagos = totalPagos + self.__listaMovimientos[i].getImporte()               
        print(f"Saldo Actualizado: {(xclienteBuscado.getSaldoAnterior()) + totalCreditos - totalPagos}")

    def consultarMovimientosClienteAbril(self, xclienteBuscado):
        print(f"Nombre y Apellido: {xclienteBuscado.getNombre()}, {xclienteBuscado.getApellido()}        Numero de cuenta: {xclienteBuscado.getNumeroDeCuenta()}")
        i = 0
        esta = False
        while i < len(self.__listaMovimientos) and esta == False:
            if self.__listaMovimientos[i].getNumeroDeCuenta() == xclienteBuscado.getNumeroDeCuenta():
                esta = True
            else:
                i=i+1
        if esta == True:
            print("Se registraron movimientos de esta cuenta en el mes de abril")
        else:
            print("No se registraron movimientos en esta cuenta")

    def agregarMovimiento(self, unMovimiento):
        if self.__cantidad == self.__dimension:
            self.__dimension = self.__dimension + self.__incremento
            self.__listaMovimientos.resize(self.__dimension)
        self.__listaMovimientos[self.__cantidad] = unMovimiento
        self.__cantidad = self.__cantidad + 1

    def getMovimiento(self, indice):
        return self.__listaMovimientos[indice]
    
    def cargaMovimientos(self):
        archivo = open("MovimientosAbril2024.csv")
        reader = csv.reader(archivo, delimiter=";")
        bandera = True
        for fila in reader:
            if bandera == True: 
                bandera = False
            else:
                numeroDeCuenta = int(fila[0])
                fecha = fila[1]
                descripcion = fila[2]
                tipoDeMovimiento = fila[3]
                importe = int(fila[4])
                unMovimiento = Movimiento(numeroDeCuenta, fecha, descripcion, tipoDeMovimiento, importe)
                self.agregarMovimiento(unMovimiento)
        archivo.close

    def ordenarPorCuenta(self):
        self.__listaMovimientos.sort()