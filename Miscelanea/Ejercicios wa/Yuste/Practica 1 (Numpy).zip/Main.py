from ClaseCliente import Cliente
from ClaseMovimiento import Movimiento
from ManejadorMovimiento import ManejadorMovimiento
from ManejadorCliente import ManejadorCliente

if __name__ == '__main__':
    mMovimientos = ManejadorMovimiento(1)
    mClientes = ManejadorCliente()
    mClientes.cargaClientes()
    mMovimientos.cargaMovimientos()
    opcion = input("""\nIngresar alguna de las siguientes opciones:
        1-Mostrar un listado de sus datos, los movimientos y el importe actualizado de un cliente
        2-Informar si un cliente tuvo movimientos durante el mes de abril 2024 
        3-Ordenar el Gestor de Movimientos por número de cuienta
        4-Mostrar Lista de Movimientos
        5-Mostrar Lista de Clientes
        0-Salir
        """)
    while opcion != "0":
        if opcion == "1":
            xDNI = int(input("Ingrese DNI del Cliente a listar: "))
            clienteBuscado = mClientes.consultarClienteCDni(xDNI) #Me retorna un objeto, un tipo de dato cliente
            mMovimientos.listarMovimientosCliente(clienteBuscado)

        elif opcion == "2":
            xDNI = int(input("Ingrese DNI del Clientea consultar si tiene movimientos en abril: "))
            clienteBuscado = mClientes.consultarClienteCDni(xDNI)
            mMovimientos.consultarMovimientosClienteAbril(clienteBuscado)
        elif opcion == "3":
            mMovimientos.ordenarPorCuenta()
            print("Movimientos ordenados correctamente")
        elif opcion == "4":
            print(mMovimientos)
        elif opcion == "5":
            print(mClientes)
        else:
            print("Opcion incorrecta")
        opcion = input("""\nIngresar alguna de las siguientes opciones:
        1-Mostrar un listado de sus datos, los movimientos y el importe actualizado de un cliente
        2-Informar si un cliente tuvo movimientos durante el mes de abril 2024 
        3-Ordenar el Gestor de Movimientos por número de cuienta
        4-Mostrar Lista de Movimientos
        5-Mostrar Lista de Clientes
        0-Salir
        """)
